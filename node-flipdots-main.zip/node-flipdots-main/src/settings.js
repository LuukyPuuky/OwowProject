export const FPS = 15;

export const LAYOUT = [
  [3, 2, 1],
  [4, 5, 6],
  [9, 8, 7],
  [10, 11, 12],
];
